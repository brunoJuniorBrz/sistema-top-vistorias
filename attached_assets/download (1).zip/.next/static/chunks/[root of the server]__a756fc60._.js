(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["static/chunks/[root of the server]__a756fc60._.js", {

"[turbopack]/browser/dev/hmr-client/hmr-client.ts [app-client] (ecmascript, async loader)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_61dcf9ba._.js",
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_3a458568._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[turbopack]/browser/dev/hmr-client/hmr-client.ts [app-client] (ecmascript)");
    });
});
}}),
"[project]/node_modules/canvg/lib/index.es.js [app-client] (ecmascript, async loader)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_9cb6a9bd._.js",
  "static/chunks/node_modules_canvg_lib_index_es_3a458568.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/node_modules/canvg/lib/index.es.js [app-client] (ecmascript)");
    });
});
}}),
"[project]/node_modules/html2canvas/dist/html2canvas.js [app-client] (ecmascript, async loader)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_html2canvas_dist_html2canvas_3938cdad.js",
  "static/chunks/node_modules_html2canvas_dist_html2canvas_3a458568.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/node_modules/html2canvas/dist/html2canvas.js [app-client] (ecmascript)");
    });
});
}}),
"[project]/node_modules/dompurify/dist/purify.js [app-client] (ecmascript, async loader)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_dompurify_dist_purify_140b3e25.js",
  "static/chunks/node_modules_dompurify_dist_purify_3a458568.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/node_modules/dompurify/dist/purify.js [app-client] (ecmascript)");
    });
});
}}),
}]);